<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="croppie.css" />
</head>

<body>

<?php

if(isset($_FILES['prime-image']))
{
 $target_file = "uploads/" . basename($_FILES["prime-image"]["name"]);
 move_uploaded_file($_FILES["prime-image"]["tmp_name"], $target_file);
 
 $cropped_image = $_POST['croppped_image'];
 

$pos  = strpos($cropped_image, ';');
$image_type_array = explode(':', substr($cropped_image, 0, $pos));

$image_ext = explode('/',$image_type_array[1]);

$img_string = strtotime(date('Y-m-d H:i:s')); 
list($type, $cropped_image) = explode(';', $cropped_image);
list(, $cropped_image)      = explode(',', $cropped_image);
$data = base64_decode($cropped_image);

$thumb_name = 'thumb'.$img_string.'.'.$image_ext[1];

file_put_contents('uploads/thumb/'.$thumb_name, $data);
 
 echo "Uploaded Images are";
 ?>
 
 <b>Main Image</b><br />
 <img src="<?=$target_file?>" />
 <br clear="all"  />
 <b>Thumb Image</b><br />
 <img src="<?='uploads/thumb/'.$thumb_name?>" />
 
 <?php
}

?>
<br clear="all" />

<h1>Pattern Upload</h1>
<form method="post" action="" enctype="multipart/form-data">
  <input type="file" id="prime-image" value="Choose a fil1e" name="prime-image"/>
  <br clear="all" />
  <br clear="all" />
  <img id="prime-preview" src="" style="width:200px;height:200px;" alt="primary image"/>
  <br clear="all" />
  <div class="actions"> <a class="btn file-btn"> <span>Upload</span>
    <input type="file" id="upload" value="Choose a file2" accept="image/*" />
    </a>
    <button class="upload-result" type="button">Result</button>
    <input type="hidden" name="croppped_image" id="croppped_image" />
  </div>
  <br clear="all" />
    <div class="upload-demo-wrap">
      <div id="upload-demo"></div>
    </div>
    
    <button type="submit">Upload Images</button>
</form>
</body>
</html>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="croppie.js"></script>
<script>

function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#prime-preview').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#prime-image").change(function(){
    readURL(this);
});

$uploadCrop = $('#upload-demo').croppie({
    enableExif: true,
    viewport: {
        width: 100,
        height: 100,
		cr_width:17,
		cr_height:17,
        type: 'square'
    },
    boundary: {
        width: 300,
        height: 300
    }
});

		$('#upload').on('change', function () { readFile(this); });
		$('.upload-result').on('click', function (ev) {
			$uploadCrop.croppie('result', {
				type: 'canvas',
				size: 'viewport'
			}).then(function (resp) {
				$('#croppped_image').val(resp);
			});
		});

		var $uploadCrop;

		function readFile(input) {
 			if (input.files && input.files[0]) {
	            var reader = new FileReader();
	            
	            reader.onload = function (e) {
					$('.upload-demo').addClass('ready');
	            	$uploadCrop.croppie('bind', {
	            		url: e.target.result
	            	});
	            	
	            }
	            
	            reader.readAsDataURL(input.files[0]);
	        }	        
		}


</script>